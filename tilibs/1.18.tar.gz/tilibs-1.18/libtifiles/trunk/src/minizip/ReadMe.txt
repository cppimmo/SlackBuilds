This folder contains files from the libz archive (contrib/minzip folder).

Files modified: Makefile for MinGW compilation.
---
roms.
