This folder contains INF files for driver installation related to libusb-win32.

---
Romain.
