You need a Windows DDK or MinGW to build this driver.
A prebuilt binary can be found in the build/msvc directory.
You need MinGW to build the executable.

BTW, don't expect high r/w performance with this way of handling i/o: 
1 KB/s for a BlaclLink cable!
