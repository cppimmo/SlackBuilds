#ifndef __BOOKMARK_H__
#define __BOOKMARK_H__

int go_to_bookmark(const char *link);

#endif
