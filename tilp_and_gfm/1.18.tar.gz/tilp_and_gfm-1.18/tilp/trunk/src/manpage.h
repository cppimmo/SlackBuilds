#ifndef __MANPAGE_H__
#define __MANPAGE_H__

#include <gtk/gtk.h>

gint display_manpage_dbox(void);

#endif
