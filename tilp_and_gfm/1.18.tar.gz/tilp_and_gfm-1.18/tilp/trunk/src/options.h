#ifndef __OPTIONS_H__
#define __OPTIONS_H__

#include <gtk/gtk.h>

gint display_options_dbox(void);

void options_radiobutton51_toggled(GtkToggleButton * togglebutton, gpointer user_data);
void options_radiobutton52_toggled(GtkToggleButton * togglebutton, gpointer user_data);
void options_checkbutton2_toggled(GtkToggleButton * togglebutton, gpointer user_data);
void options_radiobutton81_toggled(GtkToggleButton * togglebutton, gpointer user_data);
void options_radiobutton82_toggled(GtkToggleButton * togglebutton, gpointer user_data);
void options_radiobutton31_toggled(GtkToggleButton * togglebutton, gpointer user_data);
void options_radiobutton32_toggled(GtkToggleButton * togglebutton, gpointer user_data);

#endif
