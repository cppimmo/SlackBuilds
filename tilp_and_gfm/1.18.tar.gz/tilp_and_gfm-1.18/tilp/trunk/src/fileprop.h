#ifndef __FILEPROP_H__
#define __FILEPROP_H__

#include <gtk/gtk.h>

gint display_properties_dbox(const char *filename);

#endif
