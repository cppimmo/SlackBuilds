#ifndef __RELEASE_H__
#define __RELEASE_H__

#include <gtk/gtk.h>

gint display_release_dbox(void);

#endif
