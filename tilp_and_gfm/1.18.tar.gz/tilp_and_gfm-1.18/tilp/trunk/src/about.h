#ifndef __ABOUT_H__
#define __ABOUT_H__

#include <gtk/gtk.h>

gint display_about_dbox(void);

#endif
